SELECT * FROM episodes
WHERE topic LIKE "%navigation%";
