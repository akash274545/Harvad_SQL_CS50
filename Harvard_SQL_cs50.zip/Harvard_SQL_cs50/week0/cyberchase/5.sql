SELECT title FROM episodes
WHERE air_date = "2004-12-31";
