SELECT title FROM episodes
WHERE season = 1;
