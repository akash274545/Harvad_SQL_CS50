SELECT title FROM episodes
WHERE season = 5
ORDER BY title DESC;
