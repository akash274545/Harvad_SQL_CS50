select bats from players
where first_name = "Babe" AND last_name ="Ruth";
