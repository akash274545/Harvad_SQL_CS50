select id from players
where debut is null;
