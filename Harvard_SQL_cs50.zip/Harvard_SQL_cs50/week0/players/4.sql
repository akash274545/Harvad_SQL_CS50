select first_name, last_name from players
where birth_country != "USA"
order by first_name asc, last_name asc;
