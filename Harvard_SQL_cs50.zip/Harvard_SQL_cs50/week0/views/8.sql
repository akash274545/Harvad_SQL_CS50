SELECT english_title FROM views
WHERE artist = "Hokusai"
ORDER BY contrast ASC
LIMIT 5;
