SELECT MAX(contrast) AS 'Maximum Contrast'FROM views
WHERE artist = "Hokusai";
