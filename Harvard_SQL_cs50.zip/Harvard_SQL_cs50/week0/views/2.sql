SELECT average_color FROM views
WHERE artist = "Hokusai" AND english_title LIKE "%River%";
