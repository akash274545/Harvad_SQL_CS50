SELECT ENGLISH_TITLE FROM views
WHERE artist = "Hiroshige"
ORDER BY brightness DESC
LIMIT 5;
