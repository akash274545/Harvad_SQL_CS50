SELECT COUNT(english_title) FROM views
WHERE artist = "Hokusai" AND english_title LIKE "%Fuji%";
