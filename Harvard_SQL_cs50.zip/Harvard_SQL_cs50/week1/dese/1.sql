SELECT "name",
       "city"
FROM "schools"
WHERE "type" = 'Public School';
