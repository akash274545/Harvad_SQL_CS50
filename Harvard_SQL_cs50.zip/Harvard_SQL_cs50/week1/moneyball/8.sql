SELECT
	"salary"
FROM
	"salaries"
WHERE
	"player_id" = 1720
	AND "year" = 2001
ORDER BY
	"salary" DESC
LIMIT
	1;
